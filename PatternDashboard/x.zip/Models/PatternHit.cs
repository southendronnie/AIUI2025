﻿
  public class PatternHit
  {
    public DateTime Time { get; set; }
    public string Type { get; set; }
    public double Confidence { get; set; }
  }
