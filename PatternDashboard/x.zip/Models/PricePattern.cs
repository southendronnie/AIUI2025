﻿  public class PricePattern
  {
    public int StartIndex { get; set; }
    public string Direction { get; set; } = string.Empty;
  }
